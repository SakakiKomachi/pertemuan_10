<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_new extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Mlogin', 'Mlogin');
    }
    function index(){
        echo 'ddd'; die();
        if($this->session->userdata('logged') !=TRUE){
            $this->load->view('view-login');
        
        }else{
            $url=base_url('home');
            redirect($url);
        };
    }
}