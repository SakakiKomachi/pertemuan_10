<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
function __contruct(){
    parent::__construct();
    if($this->session->userdata('logged') !=TRUE){
        redirect($url);
    };
}
    public function index()
    {
    
        $this->load->view('view-home');
    }
}